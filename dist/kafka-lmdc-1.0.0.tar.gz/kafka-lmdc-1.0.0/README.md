# Python-Kafka

Esta biblioteca tem como objetivo a facilitação do uso de Kerberos e Kafka em Python.


## Como usar localmente

Para utilizar esta biblioteca localmente, é necessário cloná-la para o diretório onde se encontra o arquivo no qual você deseja importar a mesma. Isto fará com que a biblioteca esteja somente disponível para tal diretório. 

## Como usar globalmente

Para utilizar esta biblioteca globalmente, é necessário cloná-la para o diretório de bibliotecas do Python. Caso não saiba onde fica este diretório, basta:

- Abre a IDLE do Python (ou cmd)
- Importe a biblioteca sys: 
> import sys
- E digite: 
> print(sys.path)
- A saída do programa será algo parecido com: 
> C:\\Users\\marcos\\AppData\\Local\\Programs\\Python\\Python38-32\\lib\\site-packages] (saída obtida atráves do Windows)

Assim, esta biblioteca deve estar dentro do diretório **site-packages**. 
